#!/bin/sh

# change encoding type from gb18030 to utf-8

dir1=GB18030
dir2=UTF8
tar=target
temp=temp
err=fails

which iconv
if [ "$?" != "0" ]; then
    echo iconv not installed
    exit 1
fi

if [ ! -d "./$dir1" ];then
    mkdir $dir1
fi

if [ ! -d "./$dir2" ];then
    mkdir $dir2
fi

if [ ! -d "./$tar" ];then
    mkdir $tar	
fi

if [ ! -d "./$temp" ];then
    mkdir $temp
fi

if [ ! -d "./$err" ];then
    mkdir $err
fi

#cd "$dir1"

#if [ "$?" != "0" ];then
#    echo 'cd GB18030' : command error
#    exit 1
#fi


for lrc in ./$tar/*.lrc
do
    cp "$lrc" "$temp"
    iconv -f gb18030 -t utf8 "$lrc" -o "$lrc"
    if [ "$?" = "0" ];then
	mv "$lrc" "./$dir2"
	rm ./$temp/*
    else
	echo error with file $lrc, it has been move to directory fails.
	echo If the task is not completed, please execute the shell script again.
	rm "$lrc"
	mv ./$temp/*.lrc ./fails
	exit 1
    fi
done

exit 0
